package com.example.adm3000

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        gpsButton.setOnClickListener{
            val intent = Intent(this, ActivityGPS::class.java)
            startActivity(intent)
        }
        pedometerButton.setOnClickListener{
            val intent = Intent(this, ActivityPedometer::class.java)
            startActivity(intent)
        }
        antibarkButton.setOnClickListener{
            val intent = Intent(this, ActivityAntiBark::class.java)
            startActivity(intent)
        }
    }
}