package com.example.adm3000

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class ActivityGPS : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gps)

        val actionBar = supportActionBar

        actionBar!!.title = "GPS Tracker"
        actionBar.setDisplayHomeAsUpEnabled(true)
    }
}