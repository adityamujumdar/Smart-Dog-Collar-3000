package com.example.adm3000_java;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

import androidx.appcompat.app.AppCompatActivity;

//import com.rethinkdb.RethinkDB;
//import com.rethinkdb.net.Connection;
import android.os.AsyncTask;

import com.mongodb.Mongo;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.ServerAddress;

import com.mongodb.client.MongoDatabase;
import com.mongodb.client.MongoCollection;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final ImageButton button1 = findViewById(R.id.imageButton);
        button1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, GPSActivity.class));
            }
        });
    }

    public static class GPSActivity extends AppCompatActivity {

        //final RethinkDB r = RethinkDB.r;
        MongoClient mongoClient = new MongoClient();
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_gps);
            new connectDB().execute();
        }

        private class connectDB extends AsyncTask<Void,Void,Void> {

            @Override
            protected Void doInBackground(Void... voids) {
                //Connection conn = r.connection().hostname("192.168.0.50").port(28015).connect();
                //r.db("test").tableCreate("tv_shows").run(conn);
                //MongoDatabase database = mongoClient
                return null;
            }
        }
    }
}